const express = require('express');
const router = express.Router();

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    auth: {
        user: "biswaghoshctest@gmail.com",
        pass: "Test@123"
    }
});

const db = require('../database/config');
const user = require('../models/user');

router.post('/', (req, res) =>

    user.findOne(
        {
            where: {
                email: req.body.email,

            }
        }
    )
        .then((user) => {
            if (!user) {
                return res.json(
                    {
                        "success":false,
                        "message": "Entered email does not exist"
                    }
                )
            } else {

                var mailOptions = {
                    to: req.body.email,
                    subject: "Reset your password",
                    text: "This for your reset password..\n" +
                    "http://localhost:4200/resetpassword/" + req.body.email
                };
                console.log(mailOptions);
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                        user.update(
                            {
                                forgotstatus: 1
                            },
                            {
                                where: {
                                    email: req.body.email
                                }
                            }
                        ).then(
                            suceess => {
                                if (!suceess) {
                                    return res.json(
                                        {
                                            "success":false,
                                            "message": "Something went wrong"
                                        }
                                    )
                                } else {
                                    return res.json(
                                        {
                                            "success":true,
                                            "message": "Successfully sent to " + req.body.email
                                        }
                                    )
                                }


                            }
                            )

                    }
                });
            }

        })
        .catch(err => res.json(err))
);

module.exports = router;