const express = require('express');
const router = express.Router();

const db = require('../database/config');
const User = require('../models/user');

router.post('/', function (req, res) {
    User.findOne(
        {

            where: {
                email: req.body.email,
                forgotstatus:1
            }
        }
    ).then(user => {
        if (!user) {
            return res.json(
                {
                    "success":false,
                    "message": "You can not rest your password, to do so send forgot password again."
                }
            )
        } else {
            user.update(
                {
                    password: req.body.password,
                    forgotstatus: 0
                },
                {
                    where: {
                        email: req.body.email
                    }
                }
            ).then(
                success => {
                    if (!success) {
                        return res.json(
                            {
                                "message": "Unable to Reset your password, because given mail id is not proper."
                            }
                        )
                    } else {
                        return res.json(
                            {
                                "success":true,
                                "message": "Reset your password Successfully.."
                            }
                        )
                    }


                }
                )

        }
    })

});
module.exports = router;