const sequelize = require('sequelize');
const db = require('../database/config');

const user = db.define('user', {
    id: {
        type: sequelize.INTEGER,
        primaryKey: true,
        //autoIncrement: true
    },
    name: sequelize.STRING,
    email: sequelize.STRING,
    password: sequelize.TEXT,
    forgotstatus:sequelize.INTEGER

},
    {
        freezeTableName: true,
        timestamps:false
    }
);
module.exports = user;
