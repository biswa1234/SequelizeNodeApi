const express=require('express');
const bodyParser=require('body-parser');
const path=require('path');

const app=express();
const db=require('./database/config');

db.authenticate()
.then(()=>console.log('Databse connected succesfully....'))
.catch((err)=>console.log('Error occured '+err));

app.use(bodyParser.json())

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

app.get('/', require('./routs/router'));

app.use('/register',require('./routs/register'));

app.use('/login',require('./routs/login'));

app.use('/forgotpasswd',require('./routs/forgotpassword'));

app.use('/resetpasswd',require('./routs/resetpasswd'));

const PORT=process.env.PORT || 5000;

app.listen(PORT,
        console.log('Server started on port'+ PORT)
    );